# 5G DRL O-RAN Network Slicing Simulator — Full Implementation Plan

## Overview

An end-to-end, production-quality simulator implementing the research from:

> **"Deep Reinforcement Learning for Dynamic Resource Allocation in 5G Network Slicing and O-RAN"**

The system uses:
- **Multi-agent Federated Deep RL** (SAC actor-critic per base station)
- **Attention-weighted gradient aggregation** (federated coordinator)
- **Real-time O-RAN xApp simulation** (near-RT RIC at 10ms timescale)
- **Live 3D WebGL visualization** (Three.js) of resource allocation
- **Explainability layer** (SHAP-lite feature attribution)
- **FastAPI + WebSocket** streaming pipeline
- **Modular Python backend** + HTML/CSS/JS frontend

---

## Architecture Diagram

```
┌─────────────────────────────────────────────────────────────┐
│                    FRONTEND (HTML/CSS/JS)                    │
│  Tab 1: 3D Live Network   Tab 2: Agent Training Dashboard    │
│  Tab 3: Federated Learning Tab 4: Explainability (SHAP)     │
│  Tab 5: Slice Metrics      Tab 6: O-RAN xApp Console        │
│                                                             │
│         Three.js 3D    ◄──── WebSocket ────► FastAPI        │
└─────────────────────────────────────────────────────────────┘
                                  │
┌─────────────────────────────────▼───────────────────────────┐
│                  BACKEND  /backend                           │
│                                                             │
│  core/                                                      │
│    environment.py    — 5G MDP environment (slices, PRBs)    │
│    network_state.py  — Live network state manager           │
│    channel_model.py  — Rayleigh fading + path loss          │
│    traffic_model.py  — eMBB/URLLC/mMTC traffic generators   │
│                                                             │
│  agents/                                                    │
│    actor_critic.py   — SAC actor + twin critics (PyTorch)   │
│    drl_agent.py      — Per-BS DRL agent with replay buffer  │
│    multi_agent.py    — Multi-agent coordinator              │
│                                                             │
│  federated/                                                 │
│    aggregator.py     — Attention-weighted gradient agg.     │
│    fed_coordinator.py— Federated round manager             │
│                                                             │
│  explainability/                                            │
│    shap_explainer.py — Feature attribution per decision     │
│    importance.py     — Real-time importance tracking        │
│                                                             │
│  simulation/                                                │
│    simulator.py      — Main simulation loop (10ms TTI)      │
│    metrics.py        — KPI tracker (utility, energy, SLA)   │
│    oran_xapp.py      — O-RAN xApp interface layer           │
│                                                             │
│  api/                                                       │
│    main.py           — FastAPI app + REST endpoints         │
│    websocket.py      — WebSocket manager (live streaming)   │
│    routes.py         — REST API route handlers              │
└─────────────────────────────────────────────────────────────┘
```

---

## Directory Structure

```
ORAN ARCHITECTURE/
├── backend/
│   ├── core/
│   │   ├── __init__.py
│   │   ├── environment.py       # 5G MDP: state, action, reward
│   │   ├── network_state.py     # Live network state (PRBs, queues, CSI)
│   │   ├── channel_model.py     # Rayleigh fading channel simulation
│   │   └── traffic_model.py    # eMBB/URLLC/mMTC traffic generators
│   ├── agents/
│   │   ├── __init__.py
│   │   ├── actor_critic.py      # SAC neural networks (Actor + Twin Critics)
│   │   ├── drl_agent.py         # Per-BS agent with replay buffer
│   │   └── multi_agent.py      # Multi-agent coordinator
│   ├── federated/
│   │   ├── __init__.py
│   │   ├── aggregator.py        # Attention-weighted gradient aggregation
│   │   └── fed_coordinator.py  # Federated round manager
│   ├── explainability/
│   │   ├── __init__.py
│   │   ├── shap_explainer.py    # SHAP-style feature attribution
│   │   └── importance.py       # Feature importance tracker
│   ├── simulation/
│   │   ├── __init__.py
│   │   ├── simulator.py         # Main 10ms TTI simulation loop
│   │   ├── metrics.py           # KPI: utility, energy, SLA, fairness
│   │   └── oran_xapp.py        # O-RAN xApp interface/console
│   ├── api/
│   │   ├── __init__.py
│   │   ├── main.py              # FastAPI entrypoint
│   │   ├── websocket.py         # WebSocket broadcaster
│   │   └── routes.py            # REST API handlers
│   └── requirements.txt
│
├── frontend/
│   ├── index.html               # Main shell (multi-tab)
│   ├── css/
│   │   ├── main.css             # Global design system
│   │   ├── tabs.css             # Tab navigation
│   │   ├── network3d.css        # 3D scene overlay styles
│   │   └── metrics.css         # Dashboard panels
│   ├── js/
│   │   ├── app.js               # App bootstrap + WebSocket client
│   │   ├── network3d.js         # Three.js 3D network visualization
│   │   ├── training.js          # Agent training charts
│   │   ├── federated.js         # Federated learning visualization
│   │   ├── explainability.js    # SHAP bar charts + heatmaps
│   │   ├── sliceMetrics.js      # Per-slice KPI panels
│   │   └── oranConsole.js      # xApp console log + topology
│   └── assets/
│       └── (icons, fonts)
│
└── README.md
```

---

## Detailed File Descriptions

### `backend/core/environment.py`
Implements the **MDP for 5G network slicing**:
- State vector: `[PRBs_avail, slice_class, CSI, weight, fairness_idx, queue_delay]`
- Action vector: `[PRBs_per_slice, tx_power, MCS]`
- Reward: `α·throughput_norm − β·energy − γ·SLA_penalty − δ·unfairness`
- Enforces all physical constraints (max PRBs, max power, MCS bounded by CSI)

### `backend/core/channel_model.py`
- Rayleigh fading model + path loss exponent
- SINR computation from power + interference
- CQI/MCS mapping table (standard 3GPP)

### `backend/core/traffic_model.py`
- **eMBB**: Poisson-distributed traffic bursts, high throughput demand
- **URLLC**: Deterministic periodic + latency SLA constraint (<5ms)
- **mMTC**: Bursty IoT arrivals, low per-device data rate

### `backend/agents/actor_critic.py`
- **Actor network**: 3-layer FC (256-256-128) → softmax for PRBs, Gaussian for power
- **Twin Critic networks**: 3-layer FC (256-256-1) for SAC Q-value estimation
- Temperature parameter α for entropy regularization
- PyTorch-based, GPU-accelerated

### `backend/agents/drl_agent.py`
- Experience replay buffer (100,000 transitions)
- SAC training: policy gradient + value function updates
- Local training loop, exports gradient snapshots for federated

### `backend/agents/multi_agent.py`
- N agents (one per base station/cell)
- Manages training steps, episode management
- Calls federated coordinator every K steps

### `backend/federated/aggregator.py`
- Attention-weighted gradient aggregation:
  `weight_i = exp(score_i) / Σ exp(score_j)`
  where `score = recent_performance / variance`
- Global model broadcast back to all agents

### `backend/explainability/shap_explainer.py`
- Perturbation-based feature attribution (no external SHAP dependency)
- Explains each allocation decision: which state features drove it
- Returns per-feature importance vector per TTI

### `backend/simulation/simulator.py`
- **Main 10ms TTI loop** running in asyncio background task
- At each TTI: update channel → compute traffic → agents act → apply allocation → compute reward → stream via WebSocket
- Produces full `SimulationFrame` dict broadcast to all clients

### `backend/simulation/metrics.py`
- Rolling KPI tracker: network utility, SLA violation rate, energy (kWh), fairness index (Jain's)
- Exponential moving average smoothing
- Per-slice breakdown

### `backend/simulation/oran_xapp.py`
- O-RAN xApp interface simulation
- Mimics near-RT RIC: subscribes to E2 metrics, sends control decisions
- Multi-xApp consensus protocol

### `backend/api/main.py`
- FastAPI app, starts simulation loop on startup
- REST: `/api/status`, `/api/config`, `/api/metrics/history`, `/api/agents`, `/api/reset`
- WebSocket: `/ws` — streams `SimulationFrame` every 10ms TTI

### Frontend Tabs:

1. **Tab 1 — 3D Live Network** (`network3d.js`): Three.js 3D scene — base stations as glowing towers, UE devices as moving particles, resource allocation shown as colored beam pulses (eMBB=blue, URLLC=red, mMTC=green). PRB allocation shown as height/thickness of beams. Realtime animated.

2. **Tab 2 — Agent Training** (`training.js`): Live reward curve, loss curve per agent, action entropy, replay buffer fill gauge.

3. **Tab 3 — Federated Learning** (`federated.js`): Animated network graph showing gradient flow from BS agents → global coordinator → back. Attention weights shown as edge thickness. Federation round counter.

4. **Tab 4 — Explainability** (`explainability.js`): SHAP bar chart showing per-feature importance for each agent's last decision. Heatmap over time.

5. **Tab 5 — Slice Metrics** (`sliceMetrics.js`): Real-time KPI cards: Network Utility, SLA Violation %, Energy (kWh/h), Fairness Index. Per-slice throughput, latency, queue depth gauges.

6. **Tab 6 — O-RAN xApp Console** (`oranConsole.js`): Scrolling xApp log stream, E2 interface status, xApp topology diagram.

---

## Key APIs

| Endpoint | Method | Description |
|---|---|---|
| `/ws` | WebSocket | Real-time SimulationFrame stream |
| `/api/status` | GET | Simulation running status |
| `/api/metrics/history` | GET | Historical KPI time series |
| `/api/agents` | GET | Per-agent training state |
| `/api/config` | POST | Update simulation parameters |
| `/api/reset` | POST | Reset simulation |
| `/api/explainability` | GET | Latest SHAP feature attributions |
| `/api/xapp/log` | GET | O-RAN xApp console entries |

---

## Tech Stack

| Layer | Tech |
|---|---|
| Backend language | Python 3.11 |
| Deep RL framework | PyTorch |
| API server | FastAPI + uvicorn |
| Real-time comms | WebSocket (native FastAPI) |
| 3D visualization | Three.js (CDN) |
| Charts | D3.js (CDN) |
| Frontend | Vanilla HTML/CSS/JS |
| Design system | Dark glassmorphism, HSL colors |

---

## Verification Plan

1. Start backend: `cd backend && uvicorn api.main:app --reload`
2. Open `frontend/index.html` in browser
3. Verify WebSocket connection established
4. Verify 3D scene animates with real data from pipeline
5. Verify all 6 tabs render live data
6. Verify REST endpoints return valid JSON
